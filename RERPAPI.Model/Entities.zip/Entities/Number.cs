﻿using System;
using System.Collections.Generic;

namespace RERPAPI.Model.Entities;

public partial class Number
{
    public int? Num { get; set; }
}
