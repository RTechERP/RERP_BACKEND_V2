﻿using System;
using System.Collections.Generic;

namespace RERPAPI.Model.Entities;

public partial class FcmToken
{
    public int ID { get; set; }

    public string? Token { get; set; }
}
